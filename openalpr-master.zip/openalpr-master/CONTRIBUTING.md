To get started, <a href="https://cla-assistant.io/openalpr/openalpr">sign the Contributor License Agreement</a>.
